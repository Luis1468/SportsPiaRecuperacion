import pandas as pd
from cleaning import (
    handle_missing_values,
    resolve_split_records,
    standardize_text,
    map_categories,
    inches_to_cm,
    lbs_to_kg,
    validate_dataframe,
)

RAW = "../data/raw"
OUT = "../data/processed"

# Posiciones NBA
POSITION_TO_ROLE = {
    "PG": "Base",
    "SG": "Escolta",
    "SF": "Alero",
    "PF": "Ala-Pivot",
    "C": "Pivot",
}

# Mapeo equipo
TEAM_CONFERENCE = {
    "BOS": "Este", "PHI": "Este", "MIL": "Este",
    "DAL": "Oeste", "DEN": "Oeste", "GSW": "Oeste", "LAL": "Oeste", "OKC": "Oeste",
}

TEAM_ORDER = ["BOS", "DAL", "DEN", "GSW", "LAL", "MIL", "OKC", "PHI"]

def build_teams():
    ts = pd.read_csv(f"{RAW}/team_stats_per_game_2026.csv")
    ts = standardize_text(ts, ["team", "abbreviation"])

    ts["team_id"] = ts["abbreviation"].apply(lambda a: TEAM_ORDER.index(a) + 1)
    ts["conference"] = ts["abbreviation"].map(TEAM_CONFERENCE)

    teams = ts[[
        "team_id", "team", "abbreviation", "conference", "g",
        "mp_per_game", "pts_per_game", "fg_percent", "x3p_percent", "ft_percent",
        "trb_per_game", "ast_per_game", "stl_per_game", "blk_per_game", "tov_per_game",
    ]].rename(columns={
        "team": "team_name",
        "abbreviation": "team_abbr",
        "g": "games_played_season",
        "pts_per_game": "team_pts_per_game",
        "trb_per_game": "team_reb_per_game",
        "ast_per_game": "team_ast_per_game",
        "stl_per_game": "team_stl_per_game",
        "blk_per_game": "team_blk_per_game",
        "tov_per_game": "team_tov_per_game",
        "fg_percent": "team_fg_pct",
        "x3p_percent": "team_3p_pct",
        "ft_percent": "team_ft_pct",
    })

    teams = teams.sort_values("team_id").reset_index(drop=True)
    validate_dataframe(teams, ["team_id", "team_name", "team_abbr"], name="teams")
    return teams

def build_players(teams):
    pg = pd.read_csv(f"{RAW}/player_per_game_2026.csv")
    adv = pd.read_csv(f"{RAW}/advanced_2026.csv")
    sh = pd.read_csv(f"{RAW}/player_shooting_2026.csv")
    career = pd.read_csv(f"{RAW}/player_career_info.csv")

    # --- Duplicados por traspaso a mitad de temporada
    pg = resolve_split_records(pg, id_col="player_id", priority_col="g")
    adv = resolve_split_records(adv, id_col="player_id", priority_col="g")
    sh = resolve_split_records(sh, id_col="player_id", priority_col="g")

    # --- Nulos en columnas de porcentaje
    pct_cols_pg = ["fg_percent", "x3p_percent", "x2p_percent", "e_fg_percent", "ft_percent"]
    pg = handle_missing_values(pg, pct_cols_pg, strategy="zero")

    shooting_pct_cols = [c for c in sh.columns if "percent" in c]
    sh = handle_missing_values(sh, shooting_pct_cols, strategy="zero")

    # --- Normalización de texto
    pg = standardize_text(pg, ["player", "team", "pos"])
    career = standardize_text(career, ["player"])

    career_pos = career.set_index("player_id")["pos"].to_dict()
    pg["pos"] = pg.apply(
        lambda r: r["pos"] if pd.notna(r["pos"]) and r["pos"] != "nan"
        else str(career_pos.get(r["player_id"], "SF")).split("-")[0],
        axis=1,
    )

    # --- Selección de columnas relevantes
    pg_cols = [
        "player", "player_id", "team", "pos", "age", "g", "gs",
        "mp_per_game", "fg_per_game", "fga_per_game", "fg_percent",
        "x3p_per_game", "x3pa_per_game", "x3p_percent",
        "ft_per_game", "fta_per_game", "ft_percent",
        "orb_per_game", "drb_per_game", "trb_per_game",
        "ast_per_game", "stl_per_game", "blk_per_game", "tov_per_game",
        "pf_per_game", "pts_per_game",
    ]
    players = pg[pg_cols].copy()

    adv_cols = ["player_id", "per", "ts_percent", "usg_percent", "ws", "bpm", "vorp"]
    players = players.merge(adv[adv_cols], on="player_id", how="left")

    zone_cols = [
        "player_id",
        "percent_fga_from_x0_3_range", "fg_percent_from_x0_3_range",
        "percent_fga_from_x3_10_range", "fg_percent_from_x3_10_range",
        "percent_fga_from_x10_16_range", "fg_percent_from_x10_16_range",
        "percent_fga_from_x16_3p_range", "fg_percent_from_x16_3p_range",
        "percent_fga_from_x3p_range", "fg_percent_from_x3p_range",
    ]
    players = players.merge(sh[zone_cols], on="player_id", how="left")
    players = handle_missing_values(players, [c for c in zone_cols if c != "player_id"], strategy="zero")

    # --- Bio: altura / peso
    career_bio = career[["player_id", "ht_in_in", "wt"]].rename(
        columns={"ht_in_in": "height_in", "wt": "weight_lb"}
    )
    players = players.merge(career_bio, on="player_id", how="left")
    players["height_cm"] = inches_to_cm(players["height_in"])
    players["weight_kg"] = lbs_to_kg(players["weight_lb"])
    players = players.drop(columns=["height_in", "weight_lb"])
    players = handle_missing_values(players, ["height_cm", "weight_kg"], strategy="median")

    # --- Normalización de categorías
    players = map_categories(players, "pos", POSITION_TO_ROLE, new_column="role")

    # --- Relacion con teams.csv
    team_map = teams.set_index("team_abbr")["team_id"].to_dict()
    players["team_id"] = players["team"].map(team_map)
    players = players.drop(columns=["team"])

    # --- IDs propios e identificador original
    players = players.rename(columns={"player_id": "bref_id", "player": "name"})
    players = players.sort_values(["team_id", "pts_per_game"], ascending=[True, False]).reset_index(drop=True)
    players.insert(0, "player_id", range(1, len(players) + 1))

    # --- Renombrado final a esquema del proyecto
    players = players.rename(columns={
        "g": "games_played", "gs": "games_started",
        "mp_per_game": "minutes_per_game",
        "fg_per_game": "fg_made_per_game", "fga_per_game": "fg_att_per_game", "fg_percent": "fg_pct",
        "x3p_per_game": "three_made_per_game", "x3pa_per_game": "three_att_per_game", "x3p_percent": "three_pct",
        "ft_per_game": "ft_made_per_game", "fta_per_game": "ft_att_per_game", "ft_percent": "ft_pct",
        "orb_per_game": "oreb_per_game", "drb_per_game": "dreb_per_game", "trb_per_game": "reb_per_game",
        "ast_per_game": "ast_per_game", "stl_per_game": "stl_per_game", "blk_per_game": "blk_per_game",
        "tov_per_game": "tov_per_game", "pf_per_game": "pf_per_game", "pts_per_game": "pts_per_game",
        "per": "per_adv", "ts_percent": "ts_pct", "usg_percent": "usg_pct",
        "ws": "win_shares", "bpm": "bpm", "vorp": "vorp",
        "percent_fga_from_x0_3_range": "pct_fga_0_3", "fg_percent_from_x0_3_range": "fg_pct_0_3",
        "percent_fga_from_x3_10_range": "pct_fga_3_10", "fg_percent_from_x3_10_range": "fg_pct_3_10",
        "percent_fga_from_x10_16_range": "pct_fga_10_16", "fg_percent_from_x10_16_range": "fg_pct_10_16",
        "percent_fga_from_x16_3p_range": "pct_fga_16_3p", "fg_percent_from_x16_3p_range": "fg_pct_16_3p",
        "percent_fga_from_x3p_range": "pct_fga_3p", "fg_percent_from_x3p_range": "fg_pct_3p",
        "pos": "position",
    })

    validate_dataframe(
        players,
        required_columns=["player_id", "name", "team_id", "position", "role"],
        non_negative_columns=["minutes_per_game", "pts_per_game", "games_played"],
        name="players",
    )
    return players

if __name__ == "__main__":
    teams = build_teams()
    players = build_players(teams)

    teams.to_csv(f"{OUT}/teams.csv", index=False)
    players.to_csv(f"{OUT}/players.csv", index=False)

    print("teams.csv ->", teams.shape)
    print("players.csv ->", players.shape)
    print("\nteams.csv:")
    print(teams.to_string(index=False))
    print("\nplayers.csv (muestra):")
    print(players[["player_id", "name", "team_id", "position", "role", "pts_per_game", "reb_per_game", "ast_per_game"]].head(10).to_string(index=False))
