import numpy as np
import pandas as pd
from datetime import datetime, timedelta

from cleaning import (
    remove_exact_duplicates,
    handle_missing_values,
    parse_dates_flexible,
    validate_dataframe,
)

RAW = "../data/raw"
OUT = "../data/processed"

np.random.seed(42)

VENUES = {
    1: "TD Garden",
    2: "American Airlines Center",
    3: "Ball Arena",
    4: "Chase Center",
    5: "Crypto.com Arena",
    6: "Fiserv Forum",
    7: "Paycom Center",
    8: "Wells Fargo Center",
}

N_JORNADAS = 28
SEASON = "2025-26"
SEASON_START = datetime(2025, 10, 21)

# Calendario de partidos (raw, con formatos de fecha mixtos a propósito)

def generate_schedule(team_ids):
    rows = []
    match_id = 1
    for jornada in range(1, N_JORNADAS + 1):
        teams_shuffled = list(team_ids)
        np.random.shuffle(teams_shuffled)
        pairs = [(teams_shuffled[i], teams_shuffled[i + 1]) for i in range(0, 8, 2)]

        date = SEASON_START + timedelta(weeks=jornada - 1)
        # ~1 de cada 8 fechas se guarda en formato DD/MM/YYYY (dato "sucio")
        if jornada % 8 == 0:
            date_str = date.strftime("%d/%m/%Y")
        else:
            date_str = date.strftime("%Y-%m-%d")

        for t1, t2 in pairs:
            if np.random.rand() < 0.5:
                home, away = t1, t2
            else:
                home, away = t2, t1
            rows.append({
                "match_id": match_id,
                "season": SEASON,
                "date": date_str,
                "jornada": jornada,
                "home_team_id": home,
                "away_team_id": away,
                "venue": VENUES[home],
            })
            match_id += 1
    return pd.DataFrame(rows)

# Roster activo: top 10 jugadores por minutos/partido en cada equipo

def get_active_rosters(players, n=10):
    rosters = {}
    for team_id, grp in players.groupby("team_id"):
        top = grp.sort_values("minutes_per_game", ascending=False).head(n)
        rosters[team_id] = top
    return rosters

# 3. Estadisticas por partido (raw, con errores intencionados)

def generate_player_game_stats(schedule, players, rosters):
    form_series = {}
    for pid in players["player_id"]:
        forms = [max(0.5, min(1.6, 1 + np.random.normal(0, 0.08)))]
        for _ in range(N_JORNADAS - 1):
            nxt = 0.6 * forms[-1] + 0.4 * 1 + np.random.normal(0, 0.10)
            forms.append(max(0.5, min(1.6, nxt)))
        form_series[pid] = forms

    game_index = {team_id: 0 for team_id in rosters}  # nº de partido jugado por equipo
    rows = []
    stat_id = 1

    for _, match in schedule.iterrows():
        for team_id, is_home in [(match["home_team_id"], 1), (match["away_team_id"], 0)]:
            roster = rosters[team_id]
            g_idx = game_index[team_id]

            for _, p in roster.iterrows():
                play_prob = min(1.0, max(0.5, p["games_played"] / 70))
                if np.random.rand() > play_prob:
                    continue  # el jugador no participa en este partido (descanso/lesion)

                f = form_series[p["player_id"]][g_idx]
                avg_min = max(p["minutes_per_game"], 5)
                minutes = np.clip(np.random.normal(avg_min, avg_min * 0.15), 4, 40)
                scale = minutes / avg_min

                fg_att = max(0, int(np.random.poisson(max(p["fg_att_per_game"], 0.5) * f * scale)))
                three_att = min(fg_att, max(0, int(np.random.poisson(max(p["three_att_per_game"], 0.1) * f * scale))))
                two_att = fg_att - three_att

                three_pct_g = np.clip(np.random.normal(p["three_pct"], 0.12), 0, 0.75)
                two_pct_g = np.clip(np.random.normal(min(p["fg_pct"] + 0.06, 0.75), 0.10), 0.2, 0.85)

                three_made = min(three_att, int(round(three_att * three_pct_g)))
                two_made = min(two_att, int(round(two_att * two_pct_g)))
                fg_made = two_made + three_made

                ft_att = max(0, int(np.random.poisson(max(p["ft_att_per_game"], 0.3) * f * scale)))
                ft_pct_g = np.clip(np.random.normal(p["ft_pct"], 0.08), 0.3, 1.0)
                ft_made = min(ft_att, int(round(ft_att * ft_pct_g)))

                points = 2 * two_made + 3 * three_made + ft_made

                oreb = int(np.random.poisson(max(p["oreb_per_game"], 0.1) * f))
                dreb = int(np.random.poisson(max(p["dreb_per_game"], 0.1) * f))
                ast = int(np.random.poisson(max(p["ast_per_game"], 0.1) * f))
                stl = int(np.random.poisson(max(p["stl_per_game"], 0.05) * f))
                blk = int(np.random.poisson(max(p["blk_per_game"], 0.05) * f))
                tov = int(np.random.poisson(max(p["tov_per_game"], 0.1) * f))
                pf = int(np.clip(np.random.poisson(max(p["pf_per_game"], 0.5)), 0, 6))

                # --- Outliers reales intencionados
                roll = np.random.rand()
                if roll < 0.012:  # "partidazo"
                    boost = np.random.uniform(1.8, 2.4)
                    points = int(points * boost)
                    fg_made = int(fg_made * boost)
                    fg_att = max(fg_att, int(fg_att * boost))
                elif roll > 0.99:  # partido muy flojo / salida temprana por molestias
                    points = int(points * 0.15)
                    minutes = minutes * 0.3

                rows.append({
                    "stat_id": stat_id,
                    "match_id": match["match_id"],
                    "player_id": p["player_id"],
                    "team_id": team_id,
                    "is_home": is_home,
                    "minutes": round(minutes, 1),
                    "points": points,
                    "fg_made": fg_made, "fg_att": fg_att,
                    "three_made": three_made, "three_att": three_att,
                    "ft_made": ft_made, "ft_att": ft_att,
                    "oreb": oreb, "dreb": dreb, "reb": oreb + dreb,
                    "ast": ast, "stl": stl, "blk": blk, "tov": tov, "pf": pf,
                })
                stat_id += 1

            game_index[team_id] += 1

    df = pd.DataFrame(rows)

    # --- Errores intencionados para la demo de limpieza
    dup_sample = df.sample(8, random_state=1)
    df = pd.concat([df, dup_sample], ignore_index=True)

    null_idx = df.sample(15, random_state=2).index
    df.loc[null_idx, "minutes"] = np.nan

    bad_idx = df.sample(5, random_state=3).index
    df.loc[bad_idx, "fg_made"] = df.loc[bad_idx, "fg_att"] + np.random.randint(1, 3, size=5)

    return df

# Limpieza de los ficheros raw -> processed

def clean_schedule(schedule_raw):
    df = schedule_raw.copy()
    df["date"] = parse_dates_flexible(df["date"])
    df["date"] = df["date"].dt.strftime("%Y-%m-%d")
    validate_dataframe(df, ["match_id", "date", "home_team_id", "away_team_id"], name="matches")
    return df

def clean_player_game_stats(stats_raw):
    df = stats_raw.copy()


    df = remove_exact_duplicates(df, subset=["match_id", "player_id"])

    df["minutes"] = df.groupby("player_id")["minutes"].transform(
        lambda s: s.fillna(s.median())
    )
    df = handle_missing_values(df, ["minutes"], strategy="median")

    mask = df["fg_made"] > df["fg_att"]
    df.loc[mask, "fg_made"] = df.loc[mask, "fg_att"]

    validate_dataframe(
        df,
        required_columns=["stat_id", "match_id", "player_id", "team_id", "points", "minutes"],
        non_negative_columns=["points", "minutes", "fg_made", "fg_att", "reb", "ast"],
        name="player_game_stats",
    )
    return df

def recompute_match_scores(matches, stats):
    team_points = stats.groupby(["match_id", "team_id"])["points"].sum().reset_index()
    home = team_points.rename(columns={"team_id": "home_team_id", "points": "home_score"})
    away = team_points.rename(columns={"team_id": "away_team_id", "points": "away_score"})

    matches = matches.merge(home, on=["match_id", "home_team_id"], how="left")
    matches = matches.merge(away, on=["match_id", "away_team_id"], how="left")
    return matches

if __name__ == "__main__":
    players = pd.read_csv(f"{OUT}/players.csv")
    team_ids = sorted(players["team_id"].unique())

    # --- RAW
    schedule_raw = generate_schedule(team_ids)
    rosters = get_active_rosters(players, n=10)
    stats_raw = generate_player_game_stats(schedule_raw, players, rosters)

    schedule_raw.to_csv(f"{RAW}/matches_raw.csv", index=False)
    stats_raw.to_csv(f"{RAW}/player_game_stats_raw.csv", index=False)

    # --- CLEAN
    matches = clean_schedule(schedule_raw)
    stats = clean_player_game_stats(stats_raw)
    matches = recompute_match_scores(matches, stats)

    matches.to_csv(f"{OUT}/matches.csv", index=False)
    stats.to_csv(f"{OUT}/player_game_stats.csv", index=False)

    print("matches_raw ->", schedule_raw.shape, "| matches (clean) ->", matches.shape)
    print("player_game_stats_raw ->", stats_raw.shape, "| player_game_stats (clean) ->", stats.shape)
    print("\nmatches.csv (muestra):")
    print(matches.head(6).to_string(index=False))
    print("\nplayer_game_stats.csv (muestra):")
    print(stats.head(6).to_string(index=False))
    print("\nFilas con minutos nulos tras limpieza:", stats["minutes"].isna().sum())
    print("Duplicados tras limpieza:", stats.duplicated(subset=["match_id","player_id"]).sum())
