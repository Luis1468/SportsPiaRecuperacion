import io

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages

# CSV / EXCEL

def export_csv_bytes(df):
    return df.to_csv(index=False).encode("utf-8")


def export_excel_bytes(dataframes: dict):
    buffer = io.BytesIO()
    with pd.ExcelWriter(buffer, engine="openpyxl") as writer:
        for name, df in dataframes.items():
            df.to_excel(writer, sheet_name=name[:31], index=False)
    return buffer.getvalue()

# GRAFICOS (matplotlib) Y PNG

def fig_to_png_bytes(fig, dpi=150):
    """Figura matplotlib -> bytes PNG."""
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=dpi, bbox_inches="tight")
    buf.seek(0)
    return buf.getvalue()

def chart_top_scorers(players, metric="points_per_game", label="Puntos / partido", top_n=10):
    df = players.sort_values(metric, ascending=False).head(top_n)
    fig, ax = plt.subplots(figsize=(7, 5))
    ax.barh(df["name"][::-1], df[metric][::-1], color="#1f77b4")
    ax.set_xlabel(label)
    ax.set_title(f"Top {top_n} - {label}")
    fig.tight_layout()
    return fig

def chart_cluster_scatter(clustered):
    fig, ax = plt.subplots(figsize=(7, 5))
    for profile, g in clustered.groupby("profile"):
        ax.scatter(g["pca_x"], g["pca_y"], label=profile, alpha=0.7)
    ax.set_xlabel("Componente 1 (PCA)")
    ax.set_ylabel("Componente 2 (PCA)")
    ax.set_title("Segmentacion por estilo de juego")
    ax.legend()
    fig.tight_layout()
    return fig

def chart_radar(players, player_names, metrics, labels):
    angles = np.linspace(0, 2 * np.pi, len(metrics), endpoint=False).tolist()
    angles += angles[:1]

    norm = {m: (players[m].min(), players[m].max()) for m in metrics}

    fig, ax = plt.subplots(figsize=(6, 6), subplot_kw=dict(polar=True))
    for name in player_names:
        row = players[players["name"] == name].iloc[0]
        values = []
        for m in metrics:
            lo, hi = norm[m]
            values.append((row[m] - lo) / (hi - lo) if hi > lo else 0.5)
        values += values[:1]
        ax.plot(angles, values, label=name, linewidth=2)
        ax.fill(angles, values, alpha=0.1)

    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(labels)
    ax.set_yticklabels([])
    ax.set_title("Comparativa de jugadores", pad=20)
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.08), ncol=2)
    return fig

def chart_team_evolution(evo_team, team_name):
    fig, ax = plt.subplots(figsize=(7, 4))
    ax.plot(evo_team["jornada"], evo_team["points"], marker="o")
    ax.axhline(evo_team["points"].mean(), linestyle="--", color="gray", label="Media")
    ax.set_xlabel("Jornada")
    ax.set_ylabel("Puntos")
    ax.set_title(f"Evolucion de puntos - {team_name}")
    ax.legend()
    fig.tight_layout()
    return fig

# INFORME PDF

def _table_page(title, df, fig_size=(8.27, 11.69)):
    fig, ax = plt.subplots(figsize=fig_size)
    ax.axis("off")
    ax.set_title(title, fontsize=14, weight="bold", loc="left", pad=20)
    tbl = ax.table(
        cellText=df.values,
        colLabels=df.columns,
        loc="center",
        cellLoc="center",
    )
    tbl.auto_set_font_size(False)
    tbl.set_fontsize(8)
    tbl.scale(1, 1.4)
    fig.tight_layout()
    return fig


def build_pdf_report(players, teams, clustered, streaks, atypical, top_n=10):
    buffer = io.BytesIO()
    with PdfPages(buffer) as pdf:
        # --- Portada / resumen
        fig = plt.figure(figsize=(8.27, 11.69))
        fig.text(0.08, 0.92, "Sports Performance Intelligence", fontsize=22, weight="bold")
        fig.text(0.08, 0.88, "Informe de resultados - NBA Temporada 2025-26", fontsize=13)

        top_scorer = players.sort_values("points_per_game", ascending=False).iloc[0]
        summary_lines = [
            f"Equipos analizados: {teams.shape[0]}",
            f"Jugadores analizados: {players.shape[0]}",
            f"Maximo anotador: {top_scorer['name']} ({top_scorer['points_per_game']} pts/partido)",
            f"Perfiles de juego (clustering): {clustered['profile'].nunique()}",
            f"Rachas detectadas: {len(streaks)}",
            f"Partidos atipicos detectados: {len(atypical)}",
        ]
        for i, line in enumerate(summary_lines):
            fig.text(0.08, 0.80 - i * 0.04, f"- {line}", fontsize=11)

        fig.text(0.08, 0.05, "Generado automaticamente por export_utils.py", fontsize=8, color="gray")
        pdf.savefig(fig, bbox_inches="tight")
        plt.close(fig)

        # --- Top anotadores
        fig = chart_top_scorers(players, top_n=top_n)
        pdf.savefig(fig, bbox_inches="tight")
        plt.close(fig)

        # --- Radar top 2
        top2 = players.sort_values("points_per_game", ascending=False)["name"].head(2).tolist()
        radar_metrics = ["points_per_game", "reb_per_game", "assists_per_game", "stl_per_game", "blk_per_game", "offensive_efficiency"]
        radar_labels = ["Puntos", "Rebotes", "Asistencias", "Robos", "Tapones", "TS%"]
        fig = chart_radar(players, top2, radar_metrics, radar_labels)
        pdf.savefig(fig, bbox_inches="tight")
        plt.close(fig)

        # --- Clustering
        fig = chart_cluster_scatter(clustered)
        pdf.savefig(fig, bbox_inches="tight")
        plt.close(fig)

        # --- Tabla de rachas
        if len(streaks):
            cols = ["name", "tipo", "inicio_jornada", "fin_jornada", "duracion"]
            fig = _table_page("Rachas mas largas detectadas", streaks[cols].head(10))
            pdf.savefig(fig, bbox_inches="tight")
            plt.close(fig)

        # --- Tabla de partidos atipicos
        if len(atypical):
            cols = ["name", "points", "z", "tipo"]
            fig = _table_page("Partidos atipicos (z-score)", atypical[cols].head(10).round(2))
            pdf.savefig(fig, bbox_inches="tight")
            plt.close(fig)

    return buffer.getvalue()
