import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans, AgglomerativeClustering
from sklearn.decomposition import PCA
from sklearn.metrics import silhouette_score, adjusted_rand_score
from scipy.optimize import linear_sum_assignment

DATA = "../data/processed"

# --- Seleccion de variables
CLUSTER_FEATURES = [
    "pts_per_36",
    "usg_pct",
    "three_rate",
    "ast_per_36",
    "pass_precision",
    "reb_per_36",
    "stl_per_36",
    "blk_per_36",
]

def add_rate_features(players):
    df = players.copy()
    factor = 36 / df["minutes_per_game"].replace(0, np.nan)
    df["pts_per_36"] = df["points_per_game"] * factor
    df["ast_per_36"] = df["assists_per_game"] * factor
    df["reb_per_36"] = df["reb_per_game"] * factor
    df["stl_per_36"] = df["stl_per_game"] * factor
    df["blk_per_36"] = df["blk_per_game"] * factor
    df["three_rate"] = df["three_att_per_game"] / df["fg_att_per_game"].replace(0, np.nan)
    return df.fillna(0)

def select_and_scale(players, features=CLUSTER_FEATURES, min_games=10):
    df = add_rate_features(players)
    df = df[df["games_played"] >= min_games].copy().reset_index(drop=True)
    X = df[features].fillna(0)
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    return df, X_scaled

def run_kmeans(X_scaled, k=4, random_state=42):
    model = KMeans(n_clusters=k, random_state=random_state, n_init=10)
    labels = model.fit_predict(X_scaled)
    return labels, model

# --- Plantillas "ideales" de cada perfil, en espacio normalizado (z-score) 

PROFILE_TEMPLATES = {
    "Finalizador": {
        "pts_per_36": 1.5, "usg_pct": 1.5, "three_rate": 0.8,
        "ast_per_36": 0.0, "pass_precision": 0.0,
        "reb_per_36": -0.3, "stl_per_36": 0.0, "blk_per_36": -0.3,
    },
    "Creador": {
        "pts_per_36": 0.2, "usg_pct": 0.2, "three_rate": 0.0,
        "ast_per_36": 1.5, "pass_precision": 1.5,
        "reb_per_36": -0.5, "stl_per_36": 0.3, "blk_per_36": -0.5,
    },
    "Recuperador": {
        "pts_per_36": -0.3, "usg_pct": -0.3, "three_rate": -0.5,
        "ast_per_36": -0.3, "pass_precision": 0.0,
        "reb_per_36": 1.5, "stl_per_36": 1.0, "blk_per_36": 1.5,
    },
    "Jugador equilibrado": {f: 0.0 for f in CLUSTER_FEATURES},
}

def label_clusters(df, labels, features=CLUSTER_FEATURES):
    df = df.copy()
    df["cluster"] = labels

    means = df.groupby("cluster")[features].mean()
    z = (means - df[features].mean()) / df[features].std()

    profile_names = list(PROFILE_TEMPLATES.keys())
    cost = np.zeros((len(z), len(profile_names)))
    for i, c in enumerate(z.index):
        for j, p in enumerate(profile_names):
            template = np.array([PROFILE_TEMPLATES[p][f] for f in features])
            cost[i, j] = np.linalg.norm(z.loc[c].values - template)

    row_idx, col_idx = linear_sum_assignment(cost)
    profiles = {z.index[r]: profile_names[c] for r, c in zip(row_idx, col_idx)}

    df["profile"] = df["cluster"].map(profiles)
    return df, profiles

def evaluate_k_range(X_scaled, k_range=range(2, 7)):
    scores = {}
    for k in k_range:
        labels, _ = run_kmeans(X_scaled, k=k)
        scores[k] = round(silhouette_score(X_scaled, labels), 3)
    return scores

def pca_projection(X_scaled):
    pca = PCA(n_components=2, random_state=42)
    coords = pca.fit_transform(X_scaled)
    return coords, pca.explained_variance_ratio_

def compare_with_agglomerative(X_scaled, kmeans_labels, k=4):
    agg = AgglomerativeClustering(n_clusters=k)
    agg_labels = agg.fit_predict(X_scaled)
    ari = adjusted_rand_score(kmeans_labels, agg_labels)
    return agg_labels, ari
