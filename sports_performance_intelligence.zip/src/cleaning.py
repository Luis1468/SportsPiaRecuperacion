import unicodedata
import pandas as pd
import numpy as np

# Valores nulos

def handle_missing_values(df, columns, strategy="zero", fill_value=None):
    df = df.copy()
    if strategy == "drop":
        return df.dropna(subset=columns)

    for col in columns:
        if col not in df.columns:
            continue
        if strategy == "zero":
            df[col] = df[col].fillna(0)
        elif strategy == "mean":
            df[col] = df[col].fillna(df[col].mean())
        elif strategy == "median":
            df[col] = df[col].fillna(df[col].median())
        elif strategy == "value":
            df[col] = df[col].fillna(fill_value)
    return df

# Duplicados

def remove_exact_duplicates(df, subset=None):
    return df.drop_duplicates(subset=subset, keep="first").reset_index(drop=True)


def resolve_split_records(df, id_col, priority_col, keep_extra=None):
    df = df.copy()
    df = df.sort_values(priority_col, ascending=False)
    df = df.drop_duplicates(subset=id_col, keep="first")
    return df.reset_index(drop=True)

# Estandarización de nombres / texto

def standardize_text(df, columns):

    df = df.copy()
    for col in columns:
        if col not in df.columns:
            continue
        df[col] = (
            df[col]
            .astype(str)
            .str.strip()
            .str.replace(r"\s+", " ", regex=True)
            .apply(lambda x: unicodedata.normalize("NFC", x))
        )
    return df

# Normalización de categorías

def map_categories(df, column, mapping, new_column=None, default="Otro"):
    df = df.copy()
    target = new_column or column
    df[target] = df[column].map(mapping).fillna(default)
    return df

# Conversión de unidades / fechas

def inches_to_cm(series):
    return (series * 2.54).round(1)

def lbs_to_kg(series):
    return (series * 0.453592).round(1)

def parse_dates_flexible(series):
   
    parsed = pd.to_datetime(series, format="%Y-%m-%d", errors="coerce")
    mask = parsed.isna()
    if mask.any():
        parsed[mask] = pd.to_datetime(series[mask], format="%d/%m/%Y", errors="coerce")
    return parsed

# Detección de outliers

def zscore_outliers(series, threshold=3.0):
    mean, std = series.mean(), series.std()
    if std == 0 or np.isnan(std):
        return pd.Series(False, index=series.index)
    z = (series - mean) / std
    return z.abs() > threshold


def iqr_outliers(series, k=1.5):
    q1, q3 = series.quantile(0.25), series.quantile(0.75)
    iqr = q3 - q1
    low, high = q1 - k * iqr, q3 + k * iqr
    return (series < low) | (series > high)

# Validaciones automáticas

def validate_dataframe(df, required_columns, non_negative_columns=None, name="dataset"):
    missing = [c for c in required_columns if c not in df.columns]
    assert not missing, f"[{name}] Faltan columnas requeridas: {missing}"

    if non_negative_columns:
        for col in non_negative_columns:
            if col in df.columns:
                n_bad = (df[col] < 0).sum()
                assert n_bad == 0, f"[{name}] La columna '{col}' tiene {n_bad} valores negativos"

    return True
