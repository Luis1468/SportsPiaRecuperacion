from itertools import groupby

import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest

from cleaning import zscore_outliers, iqr_outliers

DATA = "../data/processed"

# ANALISIS COMPARATIVO

def rank_players(players, metric, top_n=10, ascending=False, role=None, min_games=10):
    """Ranking de jugadores por una metrica. Filtra por rol y por min. partidos jugados."""
    df = players[players["games_played"] >= min_games].copy()
    if role:
        df = df[df["role"] == role]
    cols = ["player_id", "name", "team_id", "role", metric]
    return df.sort_values(metric, ascending=ascending)[cols].head(top_n).reset_index(drop=True)


def compare_players(players, player_ids, metrics):
    """Tabla comparativa lado a lado de varios jugadores en varias metricas."""
    cols = ["player_id", "name", "role"] + metrics
    return players[players["player_id"].isin(player_ids)][cols].reset_index(drop=True)


def role_averages(players, metrics, min_games=10):
    """Media de cada metrica por rol/posicion (Base, Escolta, Alero, Ala-Pivot, Pivot)."""
    df = players[players["games_played"] >= min_games]
    return df.groupby("role")[metrics].mean().round(2)


def compare_to_role_average(players, metrics, min_games=10):
    """Para cada jugador: su valor, la media de su rol y la diferencia."""
    role_avg = role_averages(players, metrics, min_games)
    df = players[["player_id", "name", "role"] + metrics].copy()
    for m in metrics:
        df[f"{m}_media_rol"] = df["role"].map(role_avg[m])
        df[f"{m}_vs_rol"] = (df[m] - df[f"{m}_media_rol"]).round(2)
    return df

# DETECCION DE PATRONES Y ANOMALIAS

def _ordered_stats(stats, matches):
    """player_game_stats + jornada, ordenado cronologicamente por jugador."""
    df = stats.merge(matches[["match_id", "jornada"]], on="match_id")
    return df.sort_values(["player_id", "jornada"]).reset_index(drop=True)


def _find_runs(bool_list, jornadas, min_len, tipo, pid):
    """Encuentra tramos consecutivos de True de longitud >= min_len."""
    runs, idx = [], 0
    for val, grp in groupby(bool_list):
        length = len(list(grp))
        if val and length >= min_len:
            runs.append({
                "player_id": pid, "tipo": tipo,
                "inicio_jornada": int(jornadas[idx]),
                "fin_jornada": int(jornadas[idx + length - 1]),
                "duracion": length,
            })
        idx += length
    return runs


def detect_streaks(stats, matches, players, metric="points", window=3, pct=0.15):

    df = _ordered_stats(stats, matches)
    season_avg = df.groupby("player_id")[metric].transform("mean")
    df["above"] = df[metric] > season_avg * (1 + pct)
    df["below"] = df[metric] < season_avg * (1 - pct)

    all_runs = []
    for pid, g in df.groupby("player_id"):
        g = g.reset_index(drop=True)
        all_runs += _find_runs(list(g["above"]), list(g["jornada"]), window, "positiva", pid)
        all_runs += _find_runs(list(g["below"]), list(g["jornada"]), window, "negativa", pid)

    result = pd.DataFrame(all_runs)
    if len(result):
        result = result.merge(players[["player_id", "name", "team_id"]], on="player_id")
        result = result.sort_values("duracion", ascending=False).reset_index(drop=True)
    return result


def detect_atypical_matches(stats, players, metric="points", z_threshold=2.0):
    """Partidos atipicos: |z-score| >= z_threshold dentro de los partidos del propio jugador."""
    df = stats.copy()
    df["z"] = df.groupby("player_id")[metric].transform(
        lambda s: (s - s.mean()) / s.std(ddof=0) if s.std(ddof=0) > 0 else 0
    )
    atypical = df[df["z"].abs() >= z_threshold].copy()
    atypical = atypical.merge(players[["player_id", "name"]], on="player_id")
    atypical["tipo"] = np.where(atypical["z"] > 0, "partidazo", "partido flojo")
    cols = ["match_id", "player_id", "name", "team_id", metric, "z", "tipo"]
    return atypical[cols].sort_values("z", key=abs, ascending=False).reset_index(drop=True)


def detect_performance_drops(stats, matches, players, metric="points", window=5, drop_pct=0.30):
    df = _ordered_stats(stats, matches)
    drops = []
    for pid, g in df.groupby("player_id"):
        g = g.reset_index(drop=True)
        if len(g) < window + 1:
            continue
        season_avg = g[metric].mean()
        rolling = g[metric].rolling(window).mean()
        was_ok = True
        for i in range(window - 1, len(g)):
            below = rolling[i] < season_avg * (1 - drop_pct)
            if below and was_ok:
                drops.append({
                    "player_id": pid, "jornada": int(g.loc[i, "jornada"]),
                    "media_movil": round(rolling[i], 1), "media_temporada": round(season_avg, 1),
                    "caida_pct": round((1 - rolling[i] / season_avg) * 100, 1),
                })
            was_ok = not below

    result = pd.DataFrame(drops)
    if len(result):
        result = result.merge(players[["player_id", "name", "team_id"]], on="player_id")
        result = result.sort_values("caida_pct", ascending=False).reset_index(drop=True)
    return result


def detect_outlier_players(players, metrics, method="zscore", threshold=2.5, min_games=10):
    df = players[players["games_played"] >= min_games]
    rows = []
    for role, g in df.groupby("role"):
        for m in metrics:
            mask = zscore_outliers(g[m], threshold) if method == "zscore" else iqr_outliers(g[m])
            for _, r in g[mask].iterrows():
                rows.append({
                    "player_id": r["player_id"], "name": r["name"], "role": role,
                    "metrica": m, "valor": r[m], "media_rol": round(g[m].mean(), 2),
                })
    return pd.DataFrame(rows)


def isolation_forest_anomalies(stats, players, features=None, contamination=0.03):
    if features is None:
        features = ["minutes", "points", "reb", "ast", "stl", "blk", "tov"]
    X = stats[features].fillna(0)
    model = IsolationForest(contamination=contamination, random_state=42)
    df = stats.copy()
    df["anomaly"] = model.fit_predict(X)  # -1 = anomalia, 1 = normal
    out = df[df["anomaly"] == -1].merge(players[["player_id", "name"]], on="player_id")
    return out[["match_id", "player_id", "name", "team_id"] + features].reset_index(drop=True)
