import os
import sys

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "src"))
from analysis import (  # noqa: E402
    compare_to_role_average,
    detect_atypical_matches,
    detect_outlier_players,
    detect_performance_drops,
    detect_streaks,
    isolation_forest_anomalies,
    rank_players,
    role_averages,
)
from metrics import team_temporal_evolution  # noqa: E402
import export_utils as ex  # noqa: E402

DATA = "data/processed"

st.set_page_config(page_title="Sports Performance Intelligence", layout="wide", page_icon=":basketball:")

# CARGA DE DATOS (cacheada)

@st.cache_data
def load_data():
    players = pd.read_csv(f"{DATA}/players_with_metrics.csv")
    teams = pd.read_csv(f"{DATA}/teams.csv")
    matches = pd.read_csv(f"{DATA}/matches.csv")
    stats = pd.read_csv(f"{DATA}/player_game_stats.csv")
    clustered = pd.read_csv(f"{DATA}/players_clustered.csv")
    players = players.merge(teams[["team_id", "team_name", "team_abbr"]], on="team_id")
    return players, teams, matches, stats, clustered


@st.cache_data
def compute_anomalies(stats, matches, players):
    streaks = detect_streaks(stats, matches, players)
    atypical = detect_atypical_matches(stats, players)
    drops = detect_performance_drops(stats, matches, players)
    outliers = detect_outlier_players(players, ["points_per_game", "reb_per_game", "ast_per_game", "stl_per_game", "blk_per_game"])
    iso = isolation_forest_anomalies(stats, players)
    return streaks, atypical, drops, outliers, iso


players, teams, matches, stats, clustered = load_data()
streaks, atypical, drops, outliers, iso = compute_anomalies(stats, matches, players)

METRIC_LABELS = {
    "points_per_game": "Puntos / partido",
    "assists_per_game": "Asistencias / partido",
    "reb_per_game": "Rebotes / partido",
    "stl_per_game": "Robos / partido",
    "blk_per_game": "Tapones / partido",
    "shots_per_36": "Tiros / 36 min",
    "pass_precision": "Precision de pase (AST/TOV)",
    "offensive_efficiency": "Eficiencia ofensiva (TS%)",
    "xpts_per_shot": "xPTS por tiro",
    "defensive_pressure": "Presion defensiva",
    "consistency_index": "Indice de consistencia",
}

# SIDEBAR: FILTROS GLOBALES

st.sidebar.header("Filtros")
st.sidebar.caption("Temporada: 2025-26 (unica disponible)")

team_names = ["Todos"] + sorted(players["team_name"].unique().tolist())
sel_team = st.sidebar.selectbox("Equipo", team_names)

role_names = ["Todos"] + sorted(players["role"].unique().tolist())
sel_role = st.sidebar.selectbox("Rol", role_names)

min_games = st.sidebar.slider("Min. partidos jugados (temporada real)", 0, 82, 10)

filtered = players[players["games_played"] >= min_games]
if sel_team != "Todos":
    filtered = filtered[filtered["team_name"] == sel_team]
if sel_role != "Todos":
    filtered = filtered[filtered["role"] == sel_role]

st.title(":basketball: Sports Performance Intelligence")
st.caption("NBA 2025-26 · 8 equipos · " + f"{len(filtered)} jugadores tras filtros")


tab1, tab2, tab3, tab4, tab5, tab6, tab7 = st.tabs([
    "Rankings", "Comparativas", "Evolucion temporal",
    "Distribucion de eventos", "Clustering", "Patrones y anomalias", "Exportar",
])

# TAB 1: RANKINGS

with tab1:
    st.subheader("Ranking de jugadores")
    col1, col2 = st.columns([1, 2])
    with col1:
        metric = st.selectbox("Metrica", list(METRIC_LABELS.keys()), format_func=lambda k: METRIC_LABELS[k])
        top_n = st.slider("Top N", 5, 25, 10)
        ascending = st.checkbox("Orden ascendente", value=False)

    ranking = filtered.sort_values(metric, ascending=ascending).head(top_n)
    fig = px.bar(
        ranking, x=metric, y="name", orientation="h", color="team_name",
        labels={metric: METRIC_LABELS[metric], "name": "Jugador", "team_name": "Equipo"},
        title=f"Top {top_n} - {METRIC_LABELS[metric]}",
    )
    fig.update_layout(yaxis={"categoryorder": "total ascending"})
    st.plotly_chart(fig, width="stretch")

    with st.expander("Ver tabla completa"):
        cols = ["name", "team_name", "role", "games_played", metric]
        st.dataframe(filtered.sort_values(metric, ascending=ascending)[cols], width="stretch")

# TAB 2: COMPARATIVAS

with tab2:
    st.subheader("Comparativa de jugadores (radar)")

    default_players = filtered.sort_values("points_per_game", ascending=False)["name"].head(2).tolist()
    sel_players = st.multiselect("Jugadores a comparar (2-4)", filtered["name"].tolist(), default=default_players, max_selections=4)

    radar_metrics = ["points_per_game", "reb_per_game", "assists_per_game", "stl_per_game", "blk_per_game", "offensive_efficiency"]
    radar_labels = ["Puntos", "Rebotes", "Asistencias", "Robos", "Tapones", "Eficiencia (TS%)"]

    if len(sel_players) >= 2:
        # Normalizacion min-max (0-1) sobre TODOS los jugadores, para que el radar sea comparable
        norm_ranges = {m: (players[m].min(), players[m].max()) for m in radar_metrics}

        fig = go.Figure()
        for name in sel_players:
            row = players[players["name"] == name].iloc[0]
            values = []
            for m in radar_metrics:
                lo, hi = norm_ranges[m]
                values.append((row[m] - lo) / (hi - lo) if hi > lo else 0.5)
            fig.add_trace(go.Scatterpolar(r=values + values[:1], theta=radar_labels + radar_labels[:1], fill="toself", name=name))
        fig.update_layout(polar=dict(radialaxis=dict(visible=True, range=[0, 1])), title="Comparativa normalizada (0-1)")
        st.plotly_chart(fig, width="stretch")

        st.markdown("**Comparacion vs media de su rol**")
        cmp = compare_to_role_average(players, radar_metrics)
        cmp_sel = cmp[cmp["name"].isin(sel_players)]
        show_cols = ["name", "role"] + [c for m in radar_metrics for c in (m, f"{m}_vs_rol")]
        st.dataframe(cmp_sel[show_cols], width="stretch")
    else:
        st.info("Selecciona al menos 2 jugadores para comparar.")

# TAB 3: EVOLUCION TEMPORAL

with tab3:
    st.subheader("Evolucion temporal")

    col1, col2 = st.columns(2)

    with col1:
        st.markdown("**Por equipo** (puntos totales por jornada)")
        team_sel = st.selectbox("Equipo", sorted(teams["team_name"].tolist()), key="evo_team")
        tid = teams[teams["team_name"] == team_sel]["team_id"].iloc[0]
        evo = team_temporal_evolution(stats, matches)
        evo_team = evo[evo["team_id"] == tid]
        fig = px.line(evo_team, x="jornada", y="points", markers=True, labels={"points": "Puntos", "jornada": "Jornada"})
        fig.add_hline(y=evo_team["points"].mean(), line_dash="dash", annotation_text="Media")
        st.plotly_chart(fig, width="stretch")

    with col2:
        st.markdown("**Por jugador** (puntos por partido)")
        players_with_games = players[players["games_in_season"].notna()].sort_values("name")
        player_sel = st.selectbox("Jugador", players_with_games["name"].tolist(), key="evo_player")
        pid = players[players["name"] == player_sel]["player_id"].iloc[0]
        pstats = stats[stats["player_id"] == pid].merge(matches[["match_id", "jornada"]], on="match_id").sort_values("jornada")
        fig2 = px.line(pstats, x="jornada", y="points", markers=True, labels={"points": "Puntos", "jornada": "Jornada"})
        fig2.add_hline(y=pstats["points"].mean(), line_dash="dash", annotation_text="Media temporada")
        st.plotly_chart(fig2, width="stretch")

# TAB 4: DISTRIBUCION DE EVENTOS

with tab4:
    st.subheader("Distribucion de eventos")

    col1, col2 = st.columns(2)

    with col1:
        st.markdown("**Total de eventos en la temporada (8 equipos)**")
        event_cols = {"points": "Puntos", "reb": "Rebotes", "ast": "Asistencias", "stl": "Robos", "blk": "Tapones", "tov": "Perdidas", "pf": "Faltas"}
        totals = stats[list(event_cols.keys())].sum().rename(index=event_cols).reset_index()
        totals.columns = ["evento", "total"]
        fig = px.bar(totals, x="evento", y="total", labels={"evento": "Tipo de evento", "total": "Total temporada"})
        st.plotly_chart(fig, width="stretch")

    with col2:
        st.markdown("**Distribucion partido a partido**")
        event_sel = st.selectbox("Variable", list(event_cols.keys()), format_func=lambda k: event_cols[k])
        fig2 = px.histogram(stats, x=event_sel, nbins=30, labels={event_sel: event_cols[event_sel]})
        st.plotly_chart(fig2, width="stretch")

# TAB 5: CLUSTERING

with tab5:
    st.subheader("Segmentacion por estilo de juego (K-Means)")

    fig = px.scatter(
        clustered, x="pca_x", y="pca_y", color="profile",
        hover_data=["name", "team_name" if "team_name" in clustered.columns else "team_id", "role"],
        labels={"pca_x": "Componente 1 (PCA)", "pca_y": "Componente 2 (PCA)", "profile": "Perfil"},
        title="Mapa de estilos de juego (proyeccion PCA 2D)",
    )
    st.plotly_chart(fig, width="stretch")

    col1, col2 = st.columns(2)
    with col1:
        counts = clustered["profile"].value_counts().reset_index()
        counts.columns = ["perfil", "jugadores"]
        fig2 = px.bar(counts, x="perfil", y="jugadores", title="Jugadores por perfil")
        st.plotly_chart(fig2, width="stretch")

    with col2:
        profile_sel = st.selectbox("Ver jugadores del perfil:", sorted(clustered["profile"].unique()))
        cols = ["name", "team_id", "role", "pts_per_36", "ast_per_36", "reb_per_36", "stl_per_36", "blk_per_36"]
        st.dataframe(clustered[clustered["profile"] == profile_sel][cols].sort_values("pts_per_36", ascending=False), width="stretch")

# TAB 6: PATRONES Y ANOMALIAS

with tab6:
    st.subheader("Deteccion de patrones y anomalias")

    sub1, sub2, sub3 = st.tabs(["Rachas", "Partidos atipicos / Caidas", "Jugadores fuera de tendencia"])

    with sub1:
        st.markdown(f"**{len(streaks)} rachas detectadas** (>=3 partidos consecutivos por encima/debajo de su media)")
        st.dataframe(streaks[["name", "team_id", "tipo", "inicio_jornada", "fin_jornada", "duracion"]], width="stretch")

    with sub2:
        col1, col2 = st.columns(2)
        with col1:
            st.markdown(f"**Partidos atipicos (z-score)** — {len(atypical)} encontrados")
            st.dataframe(atypical.head(15), width="stretch")
        with col2:
            st.markdown(f"**Caidas bruscas de rendimiento** — {len(drops)} encontradas")
            st.dataframe(drops.head(15), width="stretch")

        st.markdown(f"**Anomalias multivariable (Isolation Forest)** — {len(iso)} partidos")
        st.dataframe(iso.head(10), width="stretch")

    with sub3:
        st.markdown("**Jugadores fuera de tendencia respecto a la media de su rol**")
        st.dataframe(outliers, width="stretch")

# TAB 7: EXPORTAR (apartado 8)

with tab7:
    st.subheader("Exportacion de resultados")
    st.caption("Genera y descarga los resultados en distintos formatos.")

    col1, col2 = st.columns(2)

    # --- CSV 
    with col1:
        st.markdown("**CSV**")
        st.download_button(
            "Descargar jugadores (players_with_metrics.csv)",
            data=ex.export_csv_bytes(players),
            file_name="players_with_metrics.csv",
            mime="text/csv",
        )
        st.download_button(
            "Descargar clustering (players_clustered.csv)",
            data=ex.export_csv_bytes(clustered),
            file_name="players_clustered.csv",
            mime="text/csv",
        )

    # --- Excel 
    with col2:
        st.markdown("**Excel (varias hojas)**")
        excel_bytes = ex.export_excel_bytes({
            "Jugadores": players,
            "Equipos": teams,
            "Partidos": matches,
            "Clustering": clustered[["player_id", "name", "team_id", "role", "profile"]],
            "Rachas": streaks,
            "Partidos_atipicos": atypical,
        })
        st.download_button(
            "Descargar informe_completo.xlsx",
            data=excel_bytes,
            file_name="informe_completo.xlsx",
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )

    st.divider()

    # --- PNG 
    st.markdown("**Imagenes PNG**")
    col3, col4 = st.columns(2)
    with col3:
        fig_png = ex.chart_top_scorers(filtered)
        st.pyplot(fig_png)
        st.download_button(
            "Descargar grafico (top anotadores).png",
            data=ex.fig_to_png_bytes(fig_png),
            file_name="top_anotadores.png",
            mime="image/png",
        )
    with col4:
        fig_png2 = ex.chart_cluster_scatter(clustered)
        st.pyplot(fig_png2)
        st.download_button(
            "Descargar grafico (clustering).png",
            data=ex.fig_to_png_bytes(fig_png2),
            file_name="clustering.png",
            mime="image/png",
        )

    st.divider()

    # --- PDF 
    st.markdown("**Informe PDF**")
    st.caption("Incluye: resumen, top anotadores, radar comparativo, clustering, rachas y partidos atipicos.")
    pdf_bytes = ex.build_pdf_report(players, teams, clustered, streaks, atypical)
    st.download_button(
        "Descargar informe_resultados.pdf",
        data=pdf_bytes,
        file_name="informe_resultados.pdf",
        mime="application/pdf",
    )
