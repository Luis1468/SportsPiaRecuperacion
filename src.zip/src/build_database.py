import sqlite3
import pandas as pd

OUT = "../data/processed"
DB_PATH = f"{OUT}/sports.db"

TABLES = ["teams", "players", "matches", "player_game_stats"]

if __name__ == "__main__":
    conn = sqlite3.connect(DB_PATH)
    for table in TABLES:
        df = pd.read_csv(f"{OUT}/{table}.csv")
        df.to_sql(table, conn, if_exists="replace", index=False)
        print(f"{table}: {df.shape[0]} filas -> tabla '{table}' en sports.db")

    # Comprobacion rapida
    check = pd.read_sql(
        """
        SELECT p.name, t.team_name, p.position, p.pts_per_game
        FROM players p
        JOIN teams t ON p.team_id = t.team_id
        ORDER BY p.pts_per_game DESC
        LIMIT 5
        """,
        conn,
    )
    print("\nTop 5 anotadores (consulta SQL de prueba):")
    print(check.to_string(index=False))

    conn.close()
