import pandas as pd
from cleaning import zscore_outliers, iqr_outliers

RAW = "../data/raw"
OUT = "../data/processed"

print("1) ANTES / DESPUES")

# --- Duplicados por traspaso
pg_raw = pd.read_csv(f"{RAW}/player_per_game_2026.csv")
players = pd.read_csv(f"{OUT}/players.csv")
print("\n[Jugador traspasado] 'Charles Bassey' en raw vs players.csv:")
print(pg_raw[pg_raw["player"] == "Charles Bassey"][["player", "team", "g", "pts_per_game"]].to_string(index=False))
print("-> en players.csv:")
print(players[players["name"] == "Charles Bassey"][["name", "team_id", "games_played", "pts_per_game"]].to_string(index=False))

# --- Nulos en porcentajes
null_example = pg_raw[pg_raw["fg_percent"].isna()][["player", "team", "fga_per_game", "fg_percent"]].head(2)
print("\n[Nulos %tiro] filas con fg_percent nulo en raw (0 intentos):")
print(null_example.to_string(index=False))
print("-> en players.csv esos jugadores tienen fg_pct = 0 (no NaN)")

# --- Fechas mixtas
matches_raw = pd.read_csv(f"{RAW}/matches_raw.csv")
matches = pd.read_csv(f"{OUT}/matches.csv")
print("\n[Fechas] jornada 8 (formato DD/MM/YYYY en raw):")
print(matches_raw[matches_raw["jornada"] == 8][["match_id", "date"]].head(2).to_string(index=False))
print("-> en matches.csv:")
print(matches[matches["jornada"] == 8][["match_id", "date"]].head(2).to_string(index=False))

# --- Duplicados y nulos en player_game_stats
stats_raw = pd.read_csv(f"{RAW}/player_game_stats_raw.csv")
stats = pd.read_csv(f"{OUT}/player_game_stats.csv")
print(f"\n[player_game_stats] filas raw: {len(stats_raw)} | duplicados: {stats_raw.duplicated(subset=['match_id','player_id']).sum()} | minutos nulos: {stats_raw['minutes'].isna().sum()}")
print(f"[player_game_stats] filas processed: {len(stats)} | duplicados: {stats.duplicated(subset=['match_id','player_id']).sum()} | minutos nulos: {stats['minutes'].isna().sum()}")

# --- Inconsistencia
bad_raw = (stats_raw["fg_made"] > stats_raw["fg_att"]).sum()
bad_clean = (stats["fg_made"] > stats["fg_att"]).sum()
print(f"\n[fg_made > fg_att] filas con error en raw: {bad_raw} | en processed: {bad_clean}")

print("\n2) DETECCION BASICA DE OUTLIERS")

# --- Outliers en players.csv
print("\n-- players.csv --")
for col in ["age", "height_cm", "minutes_per_game"]:
    mask = iqr_outliers(players[col])
    print(f"  {col}: {mask.sum()} outliers (IQR) -> {players.loc[mask, 'name'].tolist()[:5]}")

# --- Outliers en player_game_stats.csv
print("\n-- player_game_stats.csv --")
for col in ["points", "minutes", "reb", "ast"]:
    mask = zscore_outliers(stats[col], threshold=3.0)
    print(f"  {col}: {mask.sum()} outliers (z-score>3) sobre {len(stats)} filas")

mask_pts = zscore_outliers(stats["points"], threshold=3.0)
example = stats.loc[mask_pts, ["match_id", "player_id", "points", "minutes"]].merge(
    players[["player_id", "name", "pts_per_game"]], on="player_id"
).head(5)
print("\nEjemplos de partidos marcados como outlier por puntos:")
print(example.to_string(index=False))

# --- Outliers de calidad
impossible = (stats["minutes"] > 48).sum()
print(f"\nMinutos > 48 (imposible en un partido NBA): {impossible} filas")


print("\nCONCLUSION: no se detectan errores de calidad pendientes (duplicados=0,")
print("nulos=0, inconsistencias=0, minutos imposibles=0). Los outliers de")
print("rendimiento detectados son reales/intencionados y se analizan en la")
print("seccion 5 (deteccion de patrones y anomalias).")

