import numpy as np
import pandas as pd

DATA = "../data/processed"

# Valor en puntos de cada zona de tiro
ZONES = ["0_3", "3_10", "10_16", "16_3p", "3p"]
ZONE_POINTS = {"0_3": 2, "3_10": 2, "10_16": 2, "16_3p": 2, "3p": 3}

# METRICAS INDIVIDUALES

def add_individual_metrics(players, stats):
    df = players.copy()

    # --- Individuales obligatorias
    df["total_minutes"] = (df["minutes_per_game"] * df["games_played"]).round(1)

    df["shots_per_game"] = df["fg_att_per_game"]
    df["shots_per_36"] = (
        df["fg_att_per_game"] * 36 / df["minutes_per_game"].replace(0, np.nan)
    ).round(2)

    df["points_per_game"] = df["pts_per_game"]

    df["pass_precision"] = (
        df["ast_per_game"] / df["tov_per_game"].replace(0, np.nan)
    ).round(2)

    df["assists_per_game"] = df["ast_per_game"]
    df["offensive_efficiency"] = df["ts_pct"]          # True Shooting %
    df["defensive_recoveries"] = df["stl_per_game"]    # robos = recuperaciones

    xpts = pd.Series(0.0, index=df.index)
    for zone in ZONES:
        xpts += df[f"pct_fga_{zone}"] * df[f"fg_pct_{zone}"] * ZONE_POINTS[zone]
    df["xpts_per_shot"] = xpts.round(3)

    # Comparacion con el rendimiento real de tiro de campo
    actual_pts_per_shot = (
        (df["pts_per_game"] - df["ft_made_per_game"]) / df["fg_att_per_game"].replace(0, np.nan)
    )
    df["shot_quality_diff"] = (actual_pts_per_shot - df["xpts_per_shot"]).round(3)

    pct_cols = [f"pct_fga_{z}" for z in ZONES]
    fav_zone_idx = df[pct_cols].values.argmax(axis=1)
    df["favorite_zone"] = [ZONES[i] for i in fav_zone_idx]
    df["favorite_zone_fg_pct"] = [
        df.iloc[r][f"fg_pct_{ZONES[i]}"] for r, i in enumerate(fav_zone_idx)
    ]

    df["defensive_pressure"] = (
        (df["stl_per_game"] + df["blk_per_game"]) * 36 / df["minutes_per_game"].replace(0, np.nan)
    ).round(2)

    cons = consistency_index(stats)
    df = df.merge(cons[["player_id", "consistency_index", "games_in_season"]], on="player_id", how="left")

    return df

def consistency_index(stats, min_games=3):
    g = stats.groupby("player_id")["points"].agg(mean="mean", std="std", games_in_season="count")
    cv = g["std"] / g["mean"].replace(0, np.nan)
    g["consistency_index"] = (1 / (1 + cv)).round(3)
    g.loc[g["games_in_season"] < min_games, "consistency_index"] = np.nan
    return g.reset_index()[["player_id", "consistency_index", "games_in_season"]]

# METRICAS COLECTIVAS

def team_possessions(stats):
    g = stats.groupby(["match_id", "team_id"]).agg(
        fga=("fg_att", "sum"), fta=("ft_att", "sum"),
        oreb=("oreb", "sum"), tov=("tov", "sum"),
    ).reset_index()
    g["possessions"] = g["fga"] - g["oreb"] + g["tov"] + 0.44 * g["fta"]
    return g.groupby("team_id")["possessions"].mean().round(1).reset_index(name="avg_possessions")

def home_away_performance(matches):
    home = matches[["home_team_id", "home_score", "away_score"]].rename(
        columns={"home_team_id": "team_id", "home_score": "points_for", "away_score": "points_against"}
    )
    home["is_home"] = "Local"
    away = matches[["away_team_id", "away_score", "home_score"]].rename(
        columns={"away_team_id": "team_id", "away_score": "points_for", "home_score": "points_against"}
    )
    away["is_home"] = "Visitante"

    all_games = pd.concat([home, away], ignore_index=True)
    all_games["win"] = (all_games["points_for"] > all_games["points_against"]).astype(int)

    return all_games.groupby(["team_id", "is_home"]).agg(
        avg_points_for=("points_for", "mean"),
        avg_points_against=("points_against", "mean"),
        win_rate=("win", "mean"),
        games=("win", "count"),
    ).round(2).reset_index()

def compare_teams(teams, stats):
    poss = team_possessions(stats)
    return teams.merge(poss, on="team_id", how="left").sort_values("team_pts_per_game", ascending=False)

def team_temporal_evolution(stats, matches):
    team_points = stats.groupby(["match_id", "team_id"])["points"].sum().reset_index()
    team_points = team_points.merge(matches[["match_id", "jornada"]], on="match_id")
    return team_points.sort_values(["team_id", "jornada"])

# DEMO

if __name__ == "__main__":
    players = pd.read_csv(f"{DATA}/players.csv")
    teams = pd.read_csv(f"{DATA}/teams.csv")
    matches = pd.read_csv(f"{DATA}/matches.csv")
    stats = pd.read_csv(f"{DATA}/player_game_stats.csv")

    enriched = add_individual_metrics(players, stats)

    print("=== METRICAS INDIVIDUALES (top 5 puntos/partido) ===")
    cols = ["name", "team_id", "role", "points_per_game", "shots_per_36",
            "pass_precision", "offensive_efficiency", "defensive_recoveries"]
    print(enriched.sort_values("points_per_game", ascending=False)[cols].head(5).to_string(index=False))

    print("\n=== METRICAS AVANZADAS (top 5 por xPTS por tiro) ===")
    cols_adv = ["name", "xpts_per_shot", "shot_quality_diff", "favorite_zone",
                "favorite_zone_fg_pct", "defensive_pressure", "consistency_index"]
    print(enriched.sort_values("xpts_per_shot", ascending=False)[cols_adv].head(5).to_string(index=False))

    print("\n=== METRICAS COLECTIVAS: comparacion entre equipos ===")
    comp = compare_teams(teams, stats)
    print(comp[["team_name", "team_pts_per_game", "team_fg_pct", "avg_possessions"]].to_string(index=False))

    print("\n=== RENDIMIENTO LOCAL/VISITANTE (equipo 1) ===")
    ha = home_away_performance(matches)
    print(ha[ha["team_id"] == 1].to_string(index=False))

    print("\n=== EVOLUCION TEMPORAL (equipo 1, primeras 5 jornadas) ===")
    eve = team_temporal_evolution(stats, matches)
    print(eve[eve["team_id"] == 1].head(5).to_string(index=False))

    # Guardamos el dataset enriquecido para que lo use el dashboard
    enriched.to_csv(f"{DATA}/players_with_metrics.csv", index=False)
    print(f"\nGuardado: {DATA}/players_with_metrics.csv ({enriched.shape[0]} filas, {enriched.shape[1]} columnas)")